const loginForm = document.getElementById('loginForm');

const consumerNumberInput =
    document.getElementById('consumerNumber');

const passwordInput =
    document.getElementById('password');

const consumerError =
    document.getElementById('consumerError');

const passwordError =
    document.getElementById('passwordError');


if (loginForm) {

    loginForm.addEventListener('submit', function (event) {

        let isValid = true;

        consumerError.textContent = '';
        passwordError.textContent = '';


        if (!consumerNumberInput.value.trim()) {

            consumerError.textContent =
                'Consumer Number cannot be empty.';

            isValid = false;
        }


        if (!passwordInput.value.trim()) {

            passwordError.textContent =
                'Password cannot be empty.';

            isValid = false;
        }
        if (!isValid) {

            event.preventDefault();

        }

    });

}

const registerForm = document.getElementById('registerForm');

if (registerForm) {
  const regConsumerNumberInput = document.getElementById('regConsumerNumber');
  const regConsumerNameInput = document.getElementById('regConsumerName');
  const regEmailInput = document.getElementById('regEmail');
  const regPhoneInput = document.getElementById('regPhone');
  const regPasswordInput = document.getElementById('regPassword');
  const regConfirmPasswordInput = document.getElementById('regConfirmPassword');

  const regConsumerNumberError = document.getElementById('regConsumerNumberError');
  const regConsumerNameError = document.getElementById('regConsumerNameError');
  const regEmailError = document.getElementById('regEmailError');
  const regPhoneError = document.getElementById('regPhoneError');
  const regPasswordError = document.getElementById('regPasswordError');
  const regConfirmPasswordError = document.getElementById('regConfirmPasswordError');

  const emailPattern = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;
  const phonePattern = /^[0-9]{10,15}$/;

  registerForm.addEventListener('submit', function (event) {
  event.preventDefault();

    let isValid = true;

    regConsumerNumberError.textContent = '';
    regConsumerNameError.textContent = '';
    regEmailError.textContent = '';
    regPhoneError.textContent = '';
    regPasswordError.textContent = '';
    regConfirmPasswordError.textContent = '';

    if (!regConsumerNumberInput.value.trim()) {
      regConsumerNumberError.textContent = 'Consumer Number is required.';
      isValid = false;
    }

    if (!regConsumerNameInput.value.trim()) {
      regConsumerNameError.textContent = 'Consumer Name is required.';
      isValid = false;
    }

    if (!regEmailInput.value.trim()) {
      regEmailError.textContent = 'Email is required.';
      isValid = false;
    } else if (!emailPattern.test(regEmailInput.value.trim())) {
      regEmailError.textContent = 'Enter a valid email address.';
      isValid = false;
    }

    if (!regPhoneInput.value.trim()) {
      regPhoneError.textContent = 'Phone Number is required.';
      isValid = false;
    } else if (!phonePattern.test(regPhoneInput.value.trim())) {
      regPhoneError.textContent = 'Enter a valid phone number (digits only).';
      isValid = false;
    }

    if (!regPasswordInput.value.trim()) {
      regPasswordError.textContent = 'Password is required.';
      isValid = false;
    }

    if (!regConfirmPasswordInput.value.trim()) {
      regConfirmPasswordError.textContent = 'Confirm Password is required.';
      isValid = false;
    }

    if (
      regPasswordInput.value.trim() &&
      regConfirmPasswordInput.value.trim() &&
      regPasswordInput.value !== regConfirmPasswordInput.value
    ) {
      regConfirmPasswordError.textContent = 'Passwords do not match.';
      isValid = false;
    }

    if (isValid) {
      // submit the form to the server for server-side processing
      registerForm.submit();
    }
  });
}
