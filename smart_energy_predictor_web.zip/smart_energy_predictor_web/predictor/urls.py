from django.urls import path
from . import views


urlpatterns = [

    # =====================================================
    # LOGIN
    # =====================================================

    path("", views.login_selection, name="login_selection"),
    path("login/", views.login_view, name="login"),
    path("admin-login/", views.admin_login, name="admin_login"),

    path(
    "admin-dashboard/",
    views.admin_dashboard,
    name="admin_dashboard"
),

    path(
    "admin-weekly-upload/",
    views.admin_weekly_upload,
    name="admin_weekly_upload"
),




    # =====================================================
    # DASHBOARD
    # =====================================================

    path(
        "dashboard/",
        views.dashboard,
        name="dashboard"
    ),


    # =====================================================
    # PROFILE
    # =====================================================

    path(
        "profile/",
        views.profile_view,
        name="profile"
    ),


    # =====================================================
    # REGISTER
    # =====================================================

    path(
        "register/",
        views.register,
        name="register"
    ),


    # =====================================================
    # CONSUMPTION
    # =====================================================

    path(
        "consumption/",
        views.consumption,
        name="consumption"
    ),

    # =====================================================
# ADD ELECTRICITY BILL
# =====================================================

path(
    "add-bill/",
    views.add_bill,
    name="add_bill"
),

path(
    "manage-users/",
    views.manage_users,
    name="manage_users"
),

path(
    "weekly-consumption-records/",
    views.weekly_consumption_records,
    name="weekly_consumption_records"
),


    # =====================================================
    # ML PREDICTION
    # =====================================================

    path(
        "prediction/",
        views.prediction,
        name="prediction"
    ),


    # =====================================================
    # SUGGESTIONS
    # =====================================================

    path(
        "suggestions/",
        views.suggestions,
        name="suggestions"
    ),


    # =====================================================
    # REPORTS
    # =====================================================

    path(
        "reports/",
        views.reports,
        name="reports"
    ),


    # =====================================================
    # NOTIFICATIONS
    # =====================================================

    path(
        "notifications/",
        views.notifications,
        name="notifications"
    ),


    # =====================================================
    # LOGOUT
    # =====================================================

    path(
        "logout/",
        views.logout_view,
        name="logout"
    ),


    # =====================================================
    # CONSUMPTION API
    # =====================================================

    path(
        "api/consumption/<str:consumer_number>/",
        views.get_consumption,
        name="get_consumption"
    ),

]