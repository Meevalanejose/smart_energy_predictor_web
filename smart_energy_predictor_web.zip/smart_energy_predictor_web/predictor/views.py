from decimal import Decimal, InvalidOperation
from django.shortcuts import render, redirect
from django.contrib import messages
from django.http import JsonResponse
from django.utils import timezone
from django.utils.dateparse import parse_date
from datetime import date, timedelta

from sklearn.ensemble import RandomForestRegressor

from dateutil.relativedelta import relativedelta

import os
import calendar
import joblib
import pandas as pd
from .models import Notification
from .models import Users, MeterReadings, ElectricityBills, Admin, WeeklyConsumption

# =========================================================
# HELPER FUNCTION
# CALCULATE DAILY CONSUMPTION FROM CUMULATIVE METER READINGS
# =========================================================

def calculate_daily_consumption(readings):

    daily_data = {}

    previous_meter_value = None
    previous_reading = None

    for reading in readings:

        try:
            current_meter_value = float(
                reading.meter_reading
            )

        except (TypeError, ValueError):
            continue

        # -------------------------------------------------
        # FIRST READING
        # -------------------------------------------------

        if previous_meter_value is None:

            previous_meter_value = (
                current_meter_value
            )

            previous_reading = reading

            continue

        # -------------------------------------------------
        # CONSUMPTION
        # -------------------------------------------------

        consumption_value = (
            current_meter_value
            -
            previous_meter_value
        )

        # Prevent negative consumption
        if consumption_value < 0:

            consumption_value = 0.0

        # -------------------------------------------------
        # DETERMINE THE DAY TO WHICH CONSUMPTION BELONGS
        # -------------------------------------------------

        reading_date = reading.reading_date

        # Slab 3 runs from 10 PM to 6 AM.
        # Therefore, its reading is recorded at 6 AM
        # on the next calendar day.
        #
        # Example:
        # Aug 1 10 PM -> Aug 2 6 AM
        # This consumption belongs to Aug 1.

        if reading.slab == "Slab 3":

            consumption_date = (
                reading_date
                -
                timedelta(days=1)
            )

        else:

            consumption_date = reading_date

        # -------------------------------------------------
        # ADD CONSUMPTION TO DAILY TOTAL
        # -------------------------------------------------

        if consumption_date not in daily_data:

            daily_data[consumption_date] = 0.0

        daily_data[consumption_date] += (
            consumption_value
        )

        # -------------------------------------------------
        # UPDATE PREVIOUS READING
        # -------------------------------------------------

        previous_meter_value = (
            current_meter_value
        )

        previous_reading = reading

    return daily_data


def login_selection(request):

    return render(
        request,
        "login_selection.html"
    )

def admin_login(request):

    if request.method == "POST":

        username = request.POST.get("username")
        password = request.POST.get("password")

        try:
            admin = Admin.objects.get(
                username=username,
                password=password
            )

            request.session["admin_username"] = admin.username

            return redirect("admin_dashboard")

        except Admin.DoesNotExist:

            return render(
                request,
                "admin_login.html",
                {
                    "error": "Invalid username or password."
                }
            )

    return render(request, "admin_login.html")


# =========================================================
# HELPER FUNCTION
# LOAD ML MODEL
# =========================================================

def load_energy_model():

    model_path = os.path.join(

        os.path.dirname(__file__),

        "ml",

        "energy_model.pkl"
    )

    if not os.path.exists(model_path):

        return None

    try:

        model = joblib.load(
            model_path
        )

        return model

    except Exception as e:

        print(
            "Error loading energy model:",
            e
        )

        return None


# =========================================================
# HELPER FUNCTION
# PREDICT NEXT MONTH
# =========================================================

def predict_next_month_consumption(
    daily_data,
    model
):

    if model is None:

        return None

    if len(daily_data) < 7:

        return None

    # -----------------------------------------------------
    # CREATE SORTED HISTORY
    # -----------------------------------------------------

    sorted_daily_data = sorted(
        daily_data.items(),
        key=lambda item: item[0]
    )

    dates = [
        item[0]
        for item in sorted_daily_data
    ]

    values = [
        float(item[1])
        for item in sorted_daily_data
    ]

    if not dates or not values:

        return None

    # -----------------------------------------------------
    # LAST ACTUAL DATE
    # -----------------------------------------------------

    latest_date = dates[-1]

    # -----------------------------------------------------
    # FIND NEXT CALENDAR MONTH
    # -----------------------------------------------------

    next_month_date = (
        latest_date.replace(day=1)
        +
        relativedelta(months=1)
    )

    next_month_year = (
        next_month_date.year
    )

    next_month = (
        next_month_date.month
    )

    number_of_days = calendar.monthrange(
        next_month_year,
        next_month
    )[1]

    # -----------------------------------------------------
    # COPY HISTORY
    #
    # We will append predicted values to this list
    # so that future predictions can use previous
    # predicted values.
    # -----------------------------------------------------

    prediction_history = values.copy()

    total_prediction = 0.0

    predicted_daily_values = []

    # -----------------------------------------------------
    # PREDICT EACH DAY OF NEXT MONTH
    # -----------------------------------------------------

    for day in range(
        1,
        number_of_days + 1
    ):

        prediction_date = (
            next_month_date.replace(
                day=day
            )
        )

        # -------------------------------------------------
        # NEED AT LEAST 7 VALUES
        # -------------------------------------------------

        if len(prediction_history) < 7:

            return None

        # -------------------------------------------------
        # LAG VALUES
        # -------------------------------------------------

        lag_1 = float(
            prediction_history[-1]
        )

        lag_2 = float(
            prediction_history[-2]
        )

        lag_3 = float(
            prediction_history[-3]
        )

        # -------------------------------------------------
        # ROLLING 3
        # -------------------------------------------------

        rolling_3 = (
            sum(
                prediction_history[-3:]
            )
            /
            3
        )

        # -------------------------------------------------
        # ROLLING 7
        # -------------------------------------------------

        rolling_7 = (
            sum(
                prediction_history[-7:]
            )
            /
            7
        )

        # -------------------------------------------------
        # DAY OF WEEK
        # Monday = 0
        # Sunday = 6
        # -------------------------------------------------

        day_of_week = (
            prediction_date.weekday()
        )

        # -------------------------------------------------
        # WEEKEND
        # -------------------------------------------------

        is_weekend = (

            1
            if day_of_week >= 5
            else 0

        )

        # -------------------------------------------------
        # MODEL INPUT
        # -------------------------------------------------

        prediction_input = pd.DataFrame(

            [
                {

                    "lag_1":
                        lag_1,

                    "lag_2":
                        lag_2,

                    "lag_3":
                        lag_3,

                    "rolling_3":
                        rolling_3,

                    "rolling_7":
                        rolling_7,

                    "day_of_week":
                        day_of_week,

                    "is_weekend":
                        is_weekend,

                }
            ]
        )

        # -------------------------------------------------
        # MAKE PREDICTION
        # -------------------------------------------------

        try:

            predicted_value = model.predict(
                prediction_input
            )[0]

        except Exception as e:

            print(
                "Prediction error:",
                e
            )

            return None

        # -------------------------------------------------
        # CLEAN VALUE
        # -------------------------------------------------

        predicted_value = max(

            0.0,

            float(
                predicted_value
            )
        )

        predicted_value = round(
            predicted_value,
            2
        )

        # -------------------------------------------------
        # ADD TO HISTORY
        # -------------------------------------------------

        prediction_history.append(
            predicted_value
        )

        # -------------------------------------------------
        # ADD TO TOTAL
        # -------------------------------------------------

        total_prediction += (
            predicted_value
        )

        predicted_daily_values.append({

            "date":
                prediction_date,

            "consumption":
                predicted_value,

        })

    # -----------------------------------------------------
    # FINAL MONTHLY PREDICTION
    # -----------------------------------------------------

    total_prediction = round(
        total_prediction,
        2
    )

    return {

        "total":
            total_prediction,

        "daily":
            predicted_daily_values,

        "month":
            next_month_date.strftime(
                "%B %Y"
            ),

    }


# =========================================================
# LOGIN
# =========================================================

def login_view(request):

    # -----------------------------------------------------
    # IF USER SUBMITS LOGIN FORM
    # -----------------------------------------------------

    if request.method == "POST":

        # -------------------------------------------------
        # GET CONSUMER NUMBER
        # -------------------------------------------------

        consumer_number = request.POST.get(
            "consumerNumber",
            ""
        ).strip()


        # -------------------------------------------------
        # GET PASSWORD
        # -------------------------------------------------

        password = request.POST.get(
            "password",
            ""
        ).strip()


        # -------------------------------------------------
        # VALIDATE CONSUMER NUMBER
        # -------------------------------------------------

        if not consumer_number:

            messages.error(
                request,
                "Consumer Number is required."
            )

            return render(
                request,
                "index.html"
            )


        # -------------------------------------------------
        # VALIDATE PASSWORD
        # -------------------------------------------------

        if not password:

            messages.error(
                request,
                "Password is required."
            )

            return render(
                request,
                "index.html"
            )


        # -------------------------------------------------
        # FIND USER
        # -------------------------------------------------

        try:

            user = Users.objects.get(
                consumer_number=consumer_number
            )


            # ---------------------------------------------
            # CHECK PASSWORD
            # ---------------------------------------------

            if user.password == password:

                # -----------------------------------------
                # CLEAR OLD USER SESSION
                #
                # This is important when switching users.
                # -----------------------------------------

                request.session.flush()


                # -----------------------------------------
                # CREATE NEW SESSION
                # -----------------------------------------

                request.session[
                    "consumer_number"
                ] = user.consumer_number


                request.session[
                    "consumer_name"
                ] = user.name


                # -----------------------------------------
                # LOGIN SUCCESS
                # -----------------------------------------

                return redirect(
                    "dashboard"
                )


            # ---------------------------------------------
            # WRONG PASSWORD
            # ---------------------------------------------

            messages.error(
                request,
                "Incorrect password."
            )


        # -------------------------------------------------
        # CONSUMER NUMBER DOES NOT EXIST
        # -------------------------------------------------

        except Users.DoesNotExist:

            messages.error(
                request,
                "Consumer Number not found."
            )


    # -----------------------------------------------------
    # DISPLAY LOGIN PAGE
    # -----------------------------------------------------

    return render(
        request,
        "index.html"
    )


# =========================================================
# DASHBOARD
# =========================================================

def dashboard(request):

    # =====================================================
    # 1. CHECK LOGIN
    # =====================================================

    if "consumer_number" not in request.session:

        return redirect("login")

    consumer_number = request.session[
        "consumer_number"
    ]

    # =====================================================
    # 2. GET USER
    # =====================================================

    try:

        user = Users.objects.get(
            consumer_number=consumer_number
        )

    except Users.DoesNotExist:

        request.session.flush()

        return redirect("login")

    # =====================================================
    # 3. GET READINGS
    # =====================================================

    readings = list(

        MeterReadings.objects.filter(

            consumer_number_id=
                consumer_number

        ).order_by(

            "reading_date",
            "reading_time",
            "id"
        )
    )

    # =====================================================
    # 4. CALCULATE DAILY CONSUMPTION
    # =====================================================

    daily_data = calculate_daily_consumption(
        readings
    )

    # =====================================================
    # 5. GET LATEST AVAILABLE DATE
    # =====================================================

    if daily_data:

        latest_date = max(
            daily_data.keys()
        )

    else:

        latest_date = None

    # =====================================================
    # 6. LATEST RECORDED CONSUMPTION
    # =====================================================

    latest_consumption = 0.0

    if latest_date is not None:

        latest_consumption = round(

            daily_data.get(
                latest_date,
                0.0
            ),

            2
        )

    # =====================================================
    # 7. TODAY CONSUMPTION
    #
    # This variable is kept because your dashboard.html
    # currently uses {{ today_consumption }}.
    #
    # Since the database may not contain today's reading,
    # it represents the latest available recorded day.
    # =====================================================

    today_consumption = (
        latest_consumption
    )

    # =====================================================
    # 8. LAST 7 AVAILABLE DAYS
    # =====================================================

    week_consumption = 0.0

    if latest_date is not None:

        week_start = (
            latest_date
            -
            timedelta(days=6)
        )

        for reading_date, value in daily_data.items():

            if (

                week_start
                <= reading_date
                <= latest_date

            ):

                week_consumption += value

    week_consumption = round(
        week_consumption,
        2
    )

    # =====================================================
    # 9. LATEST AVAILABLE MONTH
    # =====================================================

    month_consumption = 0.0

    if latest_date is not None:

        month_start = (
            latest_date.replace(
                day=1
            )
        )

        for reading_date, value in daily_data.items():

            if (

                month_start
                <= reading_date
                <= latest_date

            ):

                month_consumption += value

    month_consumption = round(
        month_consumption,
        2
    )

    # =====================================================
    # 10. MONTHLY TOTALS FOR CHART
    # =====================================================

    monthly_totals = {}

    for reading_date, value in daily_data.items():

        month_key = (

            reading_date.year,
            reading_date.month

        )

        if month_key not in monthly_totals:

            monthly_totals[
                month_key
            ] = 0.0

        monthly_totals[
            month_key
        ] += value

    # =====================================================
    # 11. LAST 6 AVAILABLE MONTHS
    # =====================================================

    monthly_labels = []

    monthly_values = []

    if latest_date is not None:

        current_month = (
            latest_date.replace(
                day=1
            )
        )

    else:

        current_month = (
            timezone.localdate()
            .replace(
                day=1
            )
        )

    for i in range(
        5,
        -1,
        -1
    ):

        month_date = (

            current_month
            -
            relativedelta(
                months=i
            )

        )

        month_key = (

            month_date.year,
            month_date.month

        )

        monthly_labels.append(

            month_date.strftime(
                "%b %Y"
            )

        )

        monthly_values.append(

            round(

                monthly_totals.get(
                    month_key,
                    0.0
                ),

                2
            )
        )

    # =====================================================
    # 12. ML PREDICTION FOR NEXT MONTH
    # =====================================================

    predicted_next_month = None

    prediction_month = None

    if len(daily_data) >= 7:

        model = load_energy_model()

        if model is not None:

            prediction_result = (
                predict_next_month_consumption(
                    daily_data,
                    model
                )
            )

            if prediction_result is not None:

                predicted_next_month = (
                    prediction_result["total"]
                )

                prediction_month = (
                    prediction_result["month"]
                )

    # =====================================================
    # 13. CONTEXT
    # =====================================================

    context = {

        "consumer_number":
            user.consumer_number,

        "consumer_name":
            user.name,

        # Latest actual recorded consumption
        "latest_consumption":
            latest_consumption,

        # Kept for your existing dashboard.html
        "today_consumption":
            today_consumption,

        # Latest 7 available days
        "week_consumption":
            week_consumption,

        # Latest available month
        "month_consumption":
            month_consumption,

        # Chart
        "monthly_labels":
            monthly_labels,

        "monthly_values":
            monthly_values,

        # ML prediction
        "predicted_next_month":
            predicted_next_month,

        "prediction_month":
            prediction_month,

        # Latest date
        "latest_date":
            latest_date,
    }

    # =====================================================
    # 14. RENDER
    # =====================================================

    return render(
        request,
        "dashboard.html",
        context
    )

def add_bill(request):

    # Check whether user is logged in
    if "consumer_number" not in request.session:
        return redirect("login")

    consumer_number = request.session["consumer_number"]

    # Get logged-in user
    try:
        user = Users.objects.get(
            consumer_number=consumer_number
        )
    except Users.DoesNotExist:
        request.session.flush()
        return redirect("login")

    # Handle form submission
    if request.method == "POST":

        period_start = request.POST.get("period_start")
        period_end = request.POST.get("period_end")
        consumption_kwh = request.POST.get("consumption_kwh")
        bill_amount = request.POST.get("bill_amount")

        # Check empty fields
        if not all([
            period_start,
            period_end,
            consumption_kwh,
            bill_amount
        ]):

            messages.error(
                request,
                "Please fill in all fields."
            )

        else:

            try:

                start_date = parse_date(period_start)
                end_date = parse_date(period_end)

                consumption = Decimal(
                    consumption_kwh
                )

                amount = Decimal(
                    bill_amount
                )

                # Validate dates
                if not start_date or not end_date:

                    messages.error(
                        request,
                        "Please enter valid dates."
                    )

                elif end_date <= start_date:

                    messages.error(
                        request,
                        "Billing period end date must be after start date."
                    )

                # Validate numbers
                elif consumption < 0:

                    messages.error(
                        request,
                        "Consumption cannot be negative."
                    )

                elif amount < 0:

                    messages.error(
                        request,
                        "Bill amount cannot be negative."
                    )

                else:

                    # Save bill
                    ElectricityBills.objects.create(

                        consumer_number_id=consumer_number,

                        period_start=start_date,

                        period_end=end_date,

                        consumption_kwh=consumption,

                        bill_amount=amount
                    )

                    messages.success(
                        request,
                        "Electricity bill added successfully."
                    )

                    # Go to Consumption page
                    return redirect("consumption")

            except (InvalidOperation, ValueError):

                messages.error(
                    request,
                    "Please enter valid consumption and bill amount."
                )

    context = {
        

        "consumer_number": user.consumer_number,

        "consumer_name": user.name,

    }

    return render(
        request,
        "add_bill.html",
        context
    )


# =========================================================
# REGISTER
# =========================================================

def register(request):

    errors = {}

    values = {

        "regConsumerNumber": "",

        "regConsumerName": "",

        "regEmail": "",

        "regPhone": "",
    }

    if request.method == "POST":

        consumer_number = request.POST.get(
            "regConsumerNumber",
            ""
        ).strip()

        name = request.POST.get(
            "regConsumerName",
            ""
        ).strip()

        email = request.POST.get(
            "regEmail",
            ""
        ).strip()

        phone = request.POST.get(
            "regPhone",
            ""
        ).strip()

        password = request.POST.get(
            "regPassword",
            ""
        )

        confirm = request.POST.get(
            "regConfirmPassword",
            ""
        )

        values.update({

            "regConsumerNumber":
                consumer_number,

            "regConsumerName":
                name,

            "regEmail":
                email,

            "regPhone":
                phone,
        })

        # =================================================
        # VALIDATION
        # =================================================

        if not consumer_number:

            errors[
                "regConsumerNumberError"
            ] = (
                "Consumer Number is required."
            )

        if not name:

            errors[
                "regConsumerNameError"
            ] = (
                "Consumer Name is required."
            )

        if not email:

            errors[
                "regEmailError"
            ] = (
                "Email is required."
            )

        if not phone:

            errors[
                "regPhoneError"
            ] = (
                "Phone Number is required."
            )

        if not password:

            errors[
                "regPasswordError"
            ] = (
                "Password is required."
            )

        elif len(password) < 6:

            errors[
                "regPasswordError"
            ] = (
                "Password must contain "
                "at least 6 characters."
            )

        if not confirm:

            errors[
                "regConfirmPasswordError"
            ] = (
                "Please confirm your password."
            )

        elif password != confirm:

            errors[
                "regConfirmPasswordError"
            ] = (
                "Passwords do not match."
            )

        # =================================================
        # DUPLICATE CONSUMER NUMBER
        # =================================================

        if (

            consumer_number

            and

            Users.objects.filter(
                consumer_number=
                    consumer_number
            ).exists()

        ):

            errors[
                "regConsumerNumberError"
            ] = (
                "Consumer Number already exists."
            )

        # =================================================
        # SAVE USER
        # =================================================

        if not errors:

            user = Users(

                consumer_number=
                    consumer_number,

                name=
                    name,

                email=
                    email or None,

                phone=
                    phone or None,

                password=
                    password,
            )

            user.save()

            messages.success(

                request,

                "Account created successfully. "
                "Please login."
            )

            return redirect(
                "login"
            )

    return render(

        request,

        "register.html",

        {

            "errors":
                errors,

            "values":
                values,
        }
    )


# =========================================================
# PROFILE
# =========================================================

def profile(request):

    if "consumer_number" not in request.session:

        return redirect("login")

    consumer_number = request.session[
        "consumer_number"
    ]

    try:

        user = Users.objects.get(

            consumer_number=
                consumer_number
        )

    except Users.DoesNotExist:

        messages.error(
            request,
            "User not found."
        )

        return redirect(
            "login"
        )

    # =====================================================
    # UPDATE PROFILE
    # =====================================================

    if request.method == "POST":

        name = request.POST.get(
            "name",
            ""
        ).strip()

        email = request.POST.get(
            "email",
            ""
        ).strip()

        phone = request.POST.get(
            "phone",
            ""
        ).strip()

        user.name = name

        user.email = (
            email
            or None
        )

        user.phone = (
            phone
            or None
        )

        user.save()

        request.session[
            "consumer_name"
        ] = user.name

        messages.success(
            request,
            "Profile updated successfully."
        )

        return redirect(
            "profile"
        )

    context = {

        "consumer_number":
            user.consumer_number,

        "name":
            user.name,

        "email":
            user.email or "",

        "phone":
            user.phone or "",
    }

    return render(
        request,
        "profile.html",
        context
    )


# =========================================================
# PROFILE VIEW
# =========================================================

def profile_view(request):

    return profile(request)


# =========================================================
# CONSUMPTION PAGE
# =========================================================

def consumption(request):

    # =====================================================
    # CHECK LOGIN
    # =====================================================

    if "consumer_number" not in request.session:
        return redirect("login")

    consumer_number = request.session["consumer_number"]

    # =====================================================
    # GET USER
    # =====================================================

    try:
        user = Users.objects.get(
            consumer_number=consumer_number
        )

    except Users.DoesNotExist:
        request.session.flush()
        return redirect("login")

    # =====================================================
    # GET ELECTRICITY BILLS
    # =====================================================

    bills = list(
        ElectricityBills.objects.filter(
            consumer_number_id=consumer_number
        ).order_by(
            "-period_end"
        )
    )
    weekly_records = WeeklyConsumption.objects.filter(
    consumer_number_id=consumer_number
).order_by(
    "-week_end"
)

    # =====================================================
    # BILL RECORDS FOR TEMPLATE
    # =====================================================

    bill_records = []

    for bill in bills:

        bill_records.append({

            "period_start":
                bill.period_start,

            "period_end":
                bill.period_end,

            "consumption":
                float(
                    bill.consumption_kwh
                ),

            "bill_amount":
                float(
                    bill.bill_amount
                ),
        })

    # =====================================================
    # SUMMARY
    # =====================================================

    total_consumption = 0.0
    average_consumption = 0.0
    highest_consumption = 0.0
    total_bill_amount = 0.0

    if bill_records:

        consumption_values = [

            record["consumption"]

            for record in bill_records
        ]

        bill_values = [

            record["bill_amount"]

            for record in bill_records
        ]

        total_consumption = sum(
            consumption_values
        )

        average_consumption = (

            total_consumption
            /
            len(consumption_values)
        )

        highest_consumption = max(
            consumption_values
        )

        total_bill_amount = sum(
            bill_values
        )

    # =====================================================
    # LATEST BILL
    # =====================================================

    if bill_records:

        latest_bill = bill_records[0]

    else:

        latest_bill = None

    # =====================================================
    # CONTEXT
    # =====================================================

    context = {

        "consumer_number":
            user.consumer_number,

        "consumer_name":
            user.name,

        "weekly_records":
           weekly_records,

        "bills":
            bills,

        "bill_records":
            bill_records,

        "latest_bill":
            latest_bill,

        "total_consumption":
            round(
                total_consumption,
                2
            ),

        "average_consumption":
            round(
                average_consumption,
                2
            ),

        "highest_consumption":
            round(
                highest_consumption,
                2
            ),

        "total_bill_amount":
            round(
                total_bill_amount,
                2
            ),
    }

    return render(
        request,
        "consumption.html",
        context
    )

# =========================================================
# SUGGESTIONS
# =========================================================

def suggestions(request):

    # -----------------------------------------------------
    # 1. CHECK LOGIN
    # -----------------------------------------------------

    if "consumer_number" not in request.session:

        return redirect("login")


    # -----------------------------------------------------
    # 2. GET CURRENT CONSUMER NUMBER
    # -----------------------------------------------------

    consumer_number = request.session[
        "consumer_number"
    ]


    # -----------------------------------------------------
    # 3. GET CURRENT USER
    # -----------------------------------------------------

    try:

        user = Users.objects.get(
            consumer_number=consumer_number
        )

    except Users.DoesNotExist:

        request.session.flush()

        return redirect("login")


    # -----------------------------------------------------
    # 4. KEEP SESSION NAME UPDATED
    # -----------------------------------------------------

    request.session[
        "consumer_name"
    ] = user.name


    # -----------------------------------------------------
    # 5. GET BILL PREDICTION DATA
    # -----------------------------------------------------

    prediction_data = get_bill_prediction_data(
        consumer_number
    )


    # -----------------------------------------------------
    # 6. CHECK WHETHER PREDICTION IS AVAILABLE
    # -----------------------------------------------------

    if prediction_data.get("status") != "success":

        context = {

            "consumer_number":
                user.consumer_number,

            "consumer_name":
                user.name,

            "prediction_available":
                False,

            "message":
                prediction_data.get(
                    "message",
                    "Prediction data is not available."
                ),
        }

        return render(
            request,
            "suggestions.html",
            context
        )


    # -----------------------------------------------------
    # 7. GET PREDICTION VALUES
    # -----------------------------------------------------

    predicted_consumption = (
        prediction_data["prediction"]
    )

    predicted_bill = (
        prediction_data["predicted_bill"]
    )

    latest_consumption = (
        prediction_data["latest_consumption"]
    )

    average_consumption = (
        prediction_data["average_consumption"]
    )

    latest_bill_amount = (
        prediction_data["latest_bill_amount"]
    )

    suggested_bill_goal = (
        prediction_data["suggested_bill_goal"]
    )

    potential_saving = (
        prediction_data["potential_saving"]
    )


    # -----------------------------------------------------
    # 8. CALCULATE COMPARISONS
    # -----------------------------------------------------

    bill_difference_from_latest = round(
        predicted_bill
        -
        latest_bill_amount,
        2
    )

    consumption_difference_from_average = round(
        predicted_consumption
        -
        average_consumption,
        2
    )


    # -----------------------------------------------------
    # 9. CALCULATE PERCENTAGE CHANGES
    # -----------------------------------------------------

    if latest_bill_amount > 0:

        bill_change_percentage = round(
            (
                bill_difference_from_latest
                /
                latest_bill_amount
            )
            * 100,
            2
        )

    else:

        bill_change_percentage = 0


    if average_consumption > 0:

        consumption_change_percentage = round(
            (
                consumption_difference_from_average
                /
                average_consumption
            )
            * 100,
            2
        )

    else:

        consumption_change_percentage = 0


    # -----------------------------------------------------
    # 10. DETERMINE BILL TREND
    # -----------------------------------------------------
    #
    # Difference within +/- 5% is treated as stable.
    #
    # -----------------------------------------------------

    if bill_change_percentage > 5:

        bill_trend = "higher"

    elif bill_change_percentage < -5:

        bill_trend = "lower"

    else:

        bill_trend = "stable"


    # -----------------------------------------------------
    # 11. DETERMINE CONSUMPTION TREND
    # -----------------------------------------------------
    #
    # Difference within +/- 5% is treated as stable.
    #
    # -----------------------------------------------------

    if consumption_change_percentage > 5:

        consumption_trend = "higher"

    elif consumption_change_percentage < -5:

        consumption_trend = "lower"

    else:

        consumption_trend = "stable"


    # -----------------------------------------------------
    # 12. CREATE DYNAMIC MAIN SUGGESTION
    # -----------------------------------------------------

    if (
        bill_trend == "higher"
        and
        consumption_trend == "higher"
    ):

        main_suggestion_title = (
            "Higher Energy Usage Expected"
        )

        main_suggestion_message = (

            "Your predicted electricity bill is "
            "higher than your latest bill, and your "
            "predicted consumption is above your "
            "historical average. Reducing unnecessary "
            "electricity usage can help control your "
            "next bill."
        )

        main_suggestion_type = "warning"


    elif (
        bill_trend == "higher"
        and
        consumption_trend != "higher"
    ):

        main_suggestion_title = (
            "Bill May Increase"
        )

        main_suggestion_message = (

            "Your estimated next bill is more than "
            "5% higher than your latest bill. "
            "Monitor your electricity usage and "
            "avoid unnecessary consumption."
        )

        main_suggestion_type = "warning"


    elif (
        bill_trend == "lower"
        and
        consumption_trend == "lower"
    ):

        main_suggestion_title = (
            "Good Energy Trend"
        )

        main_suggestion_message = (

            "Your predicted consumption is below "
            "your historical average and your "
            "estimated bill is lower than your "
            "latest bill. Continue your "
            "energy-saving habits."
        )

        main_suggestion_type = "success"


    elif (
        bill_trend == "lower"
        and
        consumption_trend == "higher"
    ):

        main_suggestion_title = (
            "Monitor Your Consumption"
        )

        main_suggestion_message = (

            "Your estimated bill is lower than "
            "your latest bill, but your predicted "
            "consumption is above your historical "
            "average. Continue monitoring your "
            "electricity usage."
        )

        main_suggestion_type = "info"


    else:

        main_suggestion_title = (
            "Usage Is Relatively Stable"
        )

        main_suggestion_message = (

            "Your predicted consumption and "
            "estimated bill are relatively close "
            "to your recent usage. Continue "
            "monitoring your electricity "
            "consumption."
        )

        main_suggestion_type = "info"


    # -----------------------------------------------------
    # 13. CREATE PERSONALIZED ADDITIONAL SUGGESTIONS
    # -----------------------------------------------------

    suggestions_list = []


    # =====================================================
    # HIGH CONSUMPTION
    # =====================================================

    if consumption_trend == "higher":

        # First personalized action

        suggestions_list.append({

            "title":
                "Reduce Unnecessary Consumption",

            "message":
                (
                    f"Your predicted consumption is "
                    f"{abs(consumption_change_percentage):.1f}% "
                    "above your historical average. "
                    "Switch off lights, fans and appliances "
                    "when they are not required."
                ),

            "icon":
                "💡",

        })


        # Second action depends on how high
        # the consumption increase is

        if consumption_change_percentage >= 15:

            suggestions_list.append({

                "title":
                    "Reduce High-Power Appliance Usage",

                "message":
                    (
                        "Your electricity consumption is "
                        "significantly higher than your usual "
                        "usage. Try reducing the use of "
                        "air conditioners, heaters, irons "
                        "and other high-power appliances."
                    ),

                "icon":
                    "⚡",

            })

        else:

            suggestions_list.append({

                "title":
                    "Avoid Unnecessary Appliance Usage",

                "message":
                    (
                        "Your consumption is higher than "
                        "your usual level. Avoid keeping "
                        "electrical appliances running "
                        "when they are not needed."
                    ),

                "icon":
                    "🔌",

            })


    # =====================================================
    # LOW CONSUMPTION
    # =====================================================

    elif consumption_trend == "lower":

        # First personalized action

        suggestions_list.append({

            "title":
                "Continue Your Energy-Saving Habits",

            "message":
                (
                    f"Your predicted consumption is "
                    f"{abs(consumption_change_percentage):.1f}% "
                    "below your historical average. "
                    "Continue the habits that are helping "
                    "reduce your electricity usage."
                ),

            "icon":
                "🌱",

        })


        # Second action depends on how much
        # the consumption has decreased

        if abs(consumption_change_percentage) >= 15:

            suggestions_list.append({

                "title":
                    "Maintain Your Low Consumption",

                "message":
                    (
                        "Your consumption is considerably "
                        "lower than your usual usage. "
                        "Continue using electricity "
                        "efficiently and avoid unnecessary "
                        "appliance usage."
                    ),

                "icon":
                    "✅",

            })

        else:

            suggestions_list.append({

                "title":
                    "Keep Using Appliances Efficiently",

                "message":
                    (
                        "Your electricity usage is below "
                        "your historical average. Continue "
                        "using energy-efficient appliances "
                        "and avoid unnecessary standby usage."
                    ),

                "icon":
                    "⚡",

            })


    # =====================================================
    # STABLE CONSUMPTION
    # =====================================================

    else:

        suggestions_list.append({

            "title":
                "Monitor Your Electricity Usage",

            "message":
                (
                    "Your predicted consumption is close "
                    "to your historical average. Continue "
                    "checking your usage during each "
                    "billing period."
                ),

            "icon":
                "📊",

        })


        suggestions_list.append({

            "title":
                "Maintain Your Current Usage",

            "message":
                (
                    "Your electricity consumption pattern "
                    "is relatively stable. Continue "
                    "avoiding unnecessary electricity "
                    "usage to maintain this trend."
                ),

            "icon":
                "✓",

        })


    # =====================================================
    # 14. BILL-BASED PERSONALIZED RECOMMENDATION
    # =====================================================

    if bill_trend == "higher":

        suggestions_list.append({

            "title":
                "Control Your Next Bill",

            "message":
                (
                    f"Your estimated bill is "
                    f"₹{predicted_bill:.2f}, compared with "
                    f"₹{latest_bill_amount:.2f} in your "
                    "latest bill. Reducing unnecessary "
                    "consumption may help control the "
                    "increase."
                ),

            "icon":
                "💰",

        })


    elif bill_trend == "lower":

        suggestions_list.append({

            "title":
                "Keep Your Bill Trend Low",

            "message":
                (
                    f"Your estimated bill is "
                    f"₹{predicted_bill:.2f}, which is lower "
                    f"than your latest bill of "
                    f"₹{latest_bill_amount:.2f}. Continue "
                    "your current energy-saving practices."
                ),

            "icon":
                "💚",

        })


    else:

        suggestions_list.append({

            "title":
                "Keep Monitoring Your Bill",

            "message":
                (
                    "Your estimated bill is relatively "
                    "close to your latest bill. Continue "
                    "monitoring your electricity usage."
                ),

            "icon":
                "📋",

        })


    # =====================================================
    # 15. BILL GOAL RECOMMENDATION
    # =====================================================

    if predicted_bill > suggested_bill_goal:

        suggestions_list.append({

            "title":
                "Work Towards Your Suggested Goal",

            "message":
                (
                    f"Your estimated bill is "
                    f"₹{predicted_bill:.2f}. The system "
                    f"suggests aiming for approximately "
                    f"₹{suggested_bill_goal:.2f}. "
                    f"This could save up to "
                    f"₹{potential_saving:.2f}."
                ),

            "icon":
                "🎯",

        })


    # -----------------------------------------------------
    # 16. CONTEXT
    # -----------------------------------------------------

    context = {

        "consumer_number":
            user.consumer_number,

        "consumer_name":
            user.name,

        "prediction_available":
            True,


        # Prediction

        "predicted_consumption":
            predicted_consumption,

        "predicted_bill":
            predicted_bill,


        # Latest actual values

        "latest_consumption":
            latest_consumption,

        "latest_bill_amount":
            latest_bill_amount,


        # Historical average

        "average_consumption":
            average_consumption,


        # Goal

        "suggested_bill_goal":
            suggested_bill_goal,

        "potential_saving":
            potential_saving,


        # Comparisons

        "bill_difference_from_latest":
            bill_difference_from_latest,

        "consumption_difference_from_average":
            consumption_difference_from_average,

        "bill_change_percentage":
            bill_change_percentage,

        "consumption_change_percentage":
            consumption_change_percentage,

        "bill_trend":
            bill_trend,

        "consumption_trend":
            consumption_trend,


        # Main dynamic suggestion

        "main_suggestion_title":
            main_suggestion_title,

        "main_suggestion_message":
            main_suggestion_message,

        "main_suggestion_type":
            main_suggestion_type,


        # Personalized additional suggestions

        "suggestions_list":
            suggestions_list,

    }


    # -----------------------------------------------------
    # 17. RENDER
    # -----------------------------------------------------

    return render(

        request,

        "suggestions.html",

        context

    )


# =========================================================
# REPORTS
# =========================================================

def reports(request):

    if "consumer_number" not in request.session:
        return redirect("login")

    consumer_number = request.session["consumer_number"]

    try:
        user = Users.objects.get(
            consumer_number=consumer_number
        )
    except Users.DoesNotExist:
        request.session.flush()
        return redirect("login")

    # Get all bills for the logged-in consumer
    bills = list(
        ElectricityBills.objects.filter(
            consumer_number_id=consumer_number
        ).order_by("period_end")
    )

    # =====================================================
    # 6-MONTH REPORT
    # 3 bills × 2 months = approximately 6 months
    # =====================================================

    six_month_bills = bills[-3:]

    six_month_chart_data = []

    for bill in six_month_bills:

        six_month_chart_data.append({
            "label": (
                bill.period_start.strftime("%b %Y")
                + " - "
                + bill.period_end.strftime("%b %Y")
            ),
            "consumption": float(
                bill.consumption_kwh
            )
        })

    # =====================================================
    # 1-YEAR REPORT
    # 6 bills × 2 months = approximately 12 months
    # =====================================================

    one_year_bills = bills[-6:]

    one_year_chart_data = []

    for bill in one_year_bills:

        one_year_chart_data.append({
            "label": (
                bill.period_start.strftime("%b %Y")
                + " - "
                + bill.period_end.strftime("%b %Y")
            ),
            "consumption": float(
                bill.consumption_kwh
            )
        })

    # =====================================================
    # PREVIOUS VS LATEST BILL
    # =====================================================

    comparison_bills = bills[-2:]

    comparison_chart_data = []

    for bill in comparison_bills:

        comparison_chart_data.append({
            "label": (
                "Bill "
                + bill.period_start.strftime("%b %Y")
                + " - "
                + bill.period_end.strftime("%b %Y")
            ),
            "amount": float(
                bill.bill_amount
            )
        })

    # =====================================================
    # CHECK WHETHER ENOUGH DATA EXISTS
    # =====================================================

    has_six_month_report = len(bills) >= 3

    has_one_year_report = len(bills) >= 6

    has_bill_comparison = len(bills) >= 2

    # =====================================================
    # CONTEXT
    # =====================================================

    context = {

        "consumer_number":
            user.consumer_number,

        "consumer_name":
            user.name,

        "six_month_chart_data":
            six_month_chart_data,

        "one_year_chart_data":
            one_year_chart_data,

        "comparison_chart_data":
            comparison_chart_data,

        "has_six_month_report":
            has_six_month_report,

        "has_one_year_report":
            has_one_year_report,

        "has_bill_comparison":
            has_bill_comparison,
    }

    return render(
        request,
        "reports.html",
        context
    )


# =========================================================
# NOTIFICATIONS
# =========================================================




def notifications(request):

    if "consumer_number" not in request.session:
        return redirect("login")

    consumer_number = request.session["consumer_number"]

    prediction_data = get_bill_prediction_data(
        consumer_number
    )

    notification_list = Notification.objects.filter(
        consumer_number_id=consumer_number
    )

    unread_count = notification_list.filter(
        is_read=False
    ).count()

    return render(
        request,
        "notifications.html",
        {
            "consumer_number": consumer_number,
            "consumer_name": request.session.get(
                "consumer_name", ""
            ),
            "prediction_data": prediction_data,
            "notification_list": notification_list,
            "unread_count": unread_count,
        }
    )





# =========================================================
# LOGOUT
# =========================================================

def logout_view(request):

    request.session.flush()

    return redirect(
        "login"
    )


# =========================================================
# CONSUMPTION API
# =========================================================

def get_consumption(
    request,
    consumer_number
):

    readings = (

        MeterReadings.objects.filter(

            consumer_number_id=
                consumer_number

        ).order_by(

            "reading_date",
            "reading_time",
            "id"
        )
    )

    data = []

    for reading in readings:

        data.append({

            "reading_date":
                reading.reading_date.isoformat(),

            "reading_time":
                reading.reading_time.strftime(
                    "%H:%M:%S"
                ),

            "meter_reading":
                float(
                    reading.meter_reading
                ),

            "slab":
                reading.slab,
        })

    return JsonResponse({

        "success":
            True,

        "consumer_number":
            consumer_number,

        "readings":
            data,
    })

# =========================================================
# ELECTRICITY BILL PREDICTION
# =========================================================


def get_bill_prediction_data(consumer_number):
    """
    Predict the next two-month electricity consumption.

    Prediction approach:
        1. Use Random Forest Regression based on recent consumption.
        2. Do NOT use billing-period number as an ML feature.
        3. Give more importance to the user's recent consumption.
        4. Limit extreme ML predictions.
        5. Estimate the next bill using a weighted historical
           electricity rate.

    The prediction is based only on completed bill records
    available in the database.
    """

    # ---------------------------------------------------------
    # GET USER
    # ---------------------------------------------------------

    try:

        user = Users.objects.get(
            consumer_number=consumer_number
        )

    except Users.DoesNotExist:

        return {
            "status": "error",
            "message": "Consumer account not found."
        }


    # ---------------------------------------------------------
    # GET CURRENT USER'S BILL HISTORY
    # ---------------------------------------------------------

    user_bills = list(

        ElectricityBills.objects.filter(
            consumer_number_id=consumer_number
        ).order_by(
            "period_end",
            "id"
        )

    )


    # ---------------------------------------------------------
    # NEED AT LEAST 4 BILL RECORDS
    # ---------------------------------------------------------

    if len(user_bills) < 4:

        return {
            "status": "insufficient",
            "message": (
                "At least 4 completed electricity bill "
                "records are required to generate a prediction."
            )
        }


    # ---------------------------------------------------------
    # SORT USER BILLS
    # ---------------------------------------------------------

    user_bills = sorted(

        user_bills,

        key=lambda x: (
            x.period_end,
            x.id
        )

    )


    # ---------------------------------------------------------
    # GET ALL BILL RECORDS FOR ML TRAINING
    # ---------------------------------------------------------

    all_bills = list(

        ElectricityBills.objects.all().order_by(
            "consumer_number_id",
            "period_end",
            "id"
        )

    )


    # ---------------------------------------------------------
    # GROUP BILLS BY CONSUMER
    # ---------------------------------------------------------

    bills_by_consumer = {}


    for bill in all_bills:

        customer_number = bill.consumer_number_id

        if customer_number not in bills_by_consumer:

            bills_by_consumer[customer_number] = []

        bills_by_consumer[customer_number].append(
            bill
        )


    # ---------------------------------------------------------
    # BUILD ML TRAINING DATA
    #
    # IMPORTANT:
    # We removed period_no.
    #
    # The model now learns only from actual consumption
    # history:
    #
    # lag_1
    # lag_2
    # lag_3
    # rolling_3
    # ---------------------------------------------------------

    consumption_training_data = []


    for customer_number, customer_bills in (
        bills_by_consumer.items()
    ):

        customer_bills = sorted(

            customer_bills,

            key=lambda x: (
                x.period_end,
                x.id
            )

        )


        if len(customer_bills) < 4:

            continue


        consumption_values = [

            float(
                bill.consumption_kwh
            )

            for bill in customer_bills

        ]


        # -----------------------------------------------------
        # CREATE TRAINING ROWS
        # -----------------------------------------------------

        for index in range(
            3,
            len(customer_bills)
        ):

            lag_1 = consumption_values[
                index - 1
            ]

            lag_2 = consumption_values[
                index - 2
            ]

            lag_3 = consumption_values[
                index - 3
            ]


            rolling_3 = (

                lag_1
                +
                lag_2
                +
                lag_3

            ) / 3


            target = consumption_values[
                index
            ]


            consumption_training_data.append({

                "lag_1":
                    lag_1,

                "lag_2":
                    lag_2,

                "lag_3":
                    lag_3,

                "rolling_3":
                    rolling_3,

                "target":
                    target,

            })


    # ---------------------------------------------------------
    # CHECK TRAINING DATA
    # ---------------------------------------------------------

    if len(
        consumption_training_data
    ) < 5:

        return {
            "status": "insufficient",
            "message": (
                "There is not enough historical bill "
                "data to train the prediction model."
            )
        }


    # ---------------------------------------------------------
    # ML FEATURES
    #
    # period_no HAS BEEN REMOVED.
    # ---------------------------------------------------------

    consumption_features = [

        "lag_1",
        "lag_2",
        "lag_3",
        "rolling_3",

    ]


    # ---------------------------------------------------------
    # CREATE DATAFRAME
    # ---------------------------------------------------------

    training_dataframe = pd.DataFrame(
        consumption_training_data
    )


    X_consumption = training_dataframe[
        consumption_features
    ]


    y_consumption = training_dataframe[
        "target"
    ]


    # ---------------------------------------------------------
    # RANDOM FOREST MODEL
    # ---------------------------------------------------------

    consumption_model = RandomForestRegressor(

        n_estimators=200,

        max_depth=5,

        min_samples_leaf=2,

        random_state=42

    )


    consumption_model.fit(

        X_consumption,

        y_consumption

    )


    # ---------------------------------------------------------
    # GET USER'S LATEST 3 BILLS
    # ---------------------------------------------------------

    latest_three = user_bills[-3:]


    lag_1 = float(

        latest_three[-1].consumption_kwh

    )


    lag_2 = float(

        latest_three[-2].consumption_kwh

    )


    lag_3 = float(

        latest_three[-3].consumption_kwh

    )


    # ---------------------------------------------------------
    # RECENT AVERAGE
    # ---------------------------------------------------------

    recent_average = (

        lag_1
        +
        lag_2
        +
        lag_3

    ) / 3


    recent_average = max(

        0,

        recent_average

    )


    # ---------------------------------------------------------
    # WEIGHTED RECENT AVERAGE
    #
    # Latest bill gets the highest importance.
    # ---------------------------------------------------------

    weighted_recent_average = (

        (lag_1 * 0.50)
        +
        (lag_2 * 0.30)
        +
        (lag_3 * 0.20)

    )


    weighted_recent_average = max(

        0,

        weighted_recent_average

    )


    # ---------------------------------------------------------
    # PREPARE ML INPUT
    # ---------------------------------------------------------

    rolling_3 = (

        lag_1
        +
        lag_2
        +
        lag_3

    ) / 3


    next_consumption_input = pd.DataFrame([

        {

            "lag_1":
                lag_1,

            "lag_2":
                lag_2,

            "lag_3":
                lag_3,

            "rolling_3":
                rolling_3,

        }

    ])


    # ---------------------------------------------------------
    # RANDOM FOREST PREDICTION
    # ---------------------------------------------------------

    rf_prediction = float(

        consumption_model.predict(

            next_consumption_input[
                consumption_features
            ]

        )[0]

    )


    rf_prediction = max(

        0,

        rf_prediction

    )


    # ---------------------------------------------------------
    # PREVENT EXTREME ML PREDICTIONS
    #
    # The ML prediction is allowed to move around the
    # user's recent consumption, but extreme jumps are
    # limited.
    #
    # Minimum = 80% of recent weighted average
    # Maximum = 120% of recent weighted average
    # ---------------------------------------------------------

    minimum_allowed_prediction = (

        weighted_recent_average * 0.80

    )


    maximum_allowed_prediction = (

        weighted_recent_average * 1.20

    )


    rf_prediction = max(

        minimum_allowed_prediction,

        min(
            rf_prediction,
            maximum_allowed_prediction
        )

    )


    # ---------------------------------------------------------
    # FINAL CONSUMPTION PREDICTION
    #
    # 30% ML
    # 70% recent user trend
    #
    # This makes the prediction more responsive to the
    # user's actual recent usage.
    # ---------------------------------------------------------

    predicted_consumption = (

        (rf_prediction * 0.30)
        +
        (weighted_recent_average * 0.70)

    )


    predicted_consumption = max(

        0,

        predicted_consumption

    )


    predicted_consumption = round(

        predicted_consumption,

        2

    )


    # ---------------------------------------------------------
    # HISTORICAL AVERAGE CONSUMPTION
    # ---------------------------------------------------------

    all_user_consumptions = [

        float(
            bill.consumption_kwh
        )

        for bill in user_bills

    ]


    average_consumption = (

        sum(
            all_user_consumptions
        )

        /

        len(
            all_user_consumptions
        )

    )


    average_consumption = round(

        average_consumption,

        2

    )


    # ---------------------------------------------------------
    # GET LATEST BILL
    # ---------------------------------------------------------

    latest_bill = user_bills[-1]


    latest_consumption = float(

        latest_bill.consumption_kwh

    )


    latest_bill_amount = float(

        latest_bill.bill_amount

    )


    # ---------------------------------------------------------
    # CALCULATE HISTORICAL ₹ PER UNIT
    # ---------------------------------------------------------

    historical_rates = []


    for bill in user_bills:

        consumption = float(

            bill.consumption_kwh

        )


        bill_amount = float(

            bill.bill_amount

        )


        if consumption > 0:

            effective_rate = (

                bill_amount
                /
                consumption

            )

            historical_rates.append(

                effective_rate

            )


    # ---------------------------------------------------------
    # CALCULATE AVERAGE HISTORICAL RATE
    # ---------------------------------------------------------

    if historical_rates:

        average_rate_per_unit = (

            sum(
                historical_rates
            )

            /

            len(
                historical_rates
            )

        )

    else:

        average_rate_per_unit = 0.0


    # ---------------------------------------------------------
    # LATEST BILL RATE
    #
    # Give the latest bill more importance than very old
    # bills.
    # ---------------------------------------------------------

    latest_rate = 0.0


    if latest_consumption > 0:

        latest_rate = (

            latest_bill_amount
            /
            latest_consumption

        )


    # ---------------------------------------------------------
    # FINAL BILL RATE
    #
    # 60% latest bill rate
    # 40% historical average rate
    # ---------------------------------------------------------

    if latest_rate > 0 and average_rate_per_unit > 0:

        effective_rate = (

            (latest_rate * 0.60)
            +
            (average_rate_per_unit * 0.40)

        )

    elif latest_rate > 0:

        effective_rate = latest_rate

    else:

        effective_rate = average_rate_per_unit


    # ---------------------------------------------------------
    # ESTIMATE NEXT BILL
    # ---------------------------------------------------------

    predicted_bill = (

        predicted_consumption
        *
        effective_rate

    )


    predicted_bill = max(

        0,

        round(
            predicted_bill,
            2
        )

    )


    # ---------------------------------------------------------
    # CALCULATE NEXT TWO-MONTH BILLING PERIOD
    # ---------------------------------------------------------

    latest_period_end = (

        latest_bill.period_end

    )


    next_period_start = (

        latest_period_end
        +
        timedelta(days=1)

    )


    next_period_end = (

        next_period_start
        +
        relativedelta(months=2)
        -
        timedelta(days=1)

    )


    # ---------------------------------------------------------
    # SYSTEM-GENERATED BILL GOAL
    # ---------------------------------------------------------

    suggested_bill_goal = round(

        predicted_bill * 0.90,

        2

    )


    potential_saving = round(

        max(

            0,

            predicted_bill
            -
            suggested_bill_goal

        ),

        2

    )


    # ---------------------------------------------------------
    # RETURN DATA
    # ---------------------------------------------------------

    return {

        "status":
            "success",

        "consumer_number":
            user.consumer_number,

        "consumer_name":
            user.name,

        "prediction":
            predicted_consumption,

        "predicted_bill":
            predicted_bill,

        "latest_consumption":
            round(
                latest_consumption,
                2
            ),

        "average_consumption":
            average_consumption,

        "latest_bill_amount":
            round(
                latest_bill_amount,
                2
            ),

        "average_rate_per_unit":
            round(
                effective_rate,
                2
            ),

        "suggested_bill_goal":
            suggested_bill_goal,

        "potential_saving":
            potential_saving,

        "next_period_start":
            next_period_start,

        "next_period_end":
            next_period_end,

    }



# =========================================================
# PREDICTION PAGE
# =========================================================

def prediction(request):

    # Check login
    if "consumer_number" not in request.session:
        return redirect("login")

    # Get consumer number
    consumer_number = request.session["consumer_number"]

    # Get user
    try:
        user = Users.objects.get(
            consumer_number=consumer_number
        )
    except Users.DoesNotExist:
        request.session.flush()
        return redirect("login")

    # Get prediction data
    prediction_data = get_bill_prediction_data(
        consumer_number
    )

    # Prediction not available
    if prediction_data.get("status") != "success":

        context = {
            "consumer_number": user.consumer_number,
            "consumer_name": user.name,
            "prediction": None,
            "predicted_bill": None,
            "latest_consumption": None,
            "average_consumption": None,
            "latest_bill_amount": None,
            "average_rate_per_unit": None,
            "suggested_bill_goal": None,
            "potential_saving": None,
            "next_period_start": None,
            "next_period_end": None,
            "message": prediction_data.get(
                "message",
                "Prediction data is not available."
            ),
        }

        return render(
            request,
            "prediction.html",
            context
        )

    # Successful prediction
    next_period_start = prediction_data["next_period_start"]
    next_period_end = prediction_data["next_period_end"]
    predicted_bill = prediction_data["predicted_bill"]

    # Create notification for a new bill prediction
    prediction_title = "New Bill Prediction Available"

    period_identifier = (
        f"Billing period: {next_period_start} to {next_period_end}."
    )

    existing_notification = Notification.objects.filter(
        consumer_number_id=consumer_number,
        title=prediction_title,
        message__contains=period_identifier
    ).exists()

    if not existing_notification:
        Notification.objects.create(
            consumer_number_id=consumer_number,
            title=prediction_title,
            message=(
                f"Your estimated electricity bill for the period "
                f"{next_period_start} to {next_period_end} is "
                f"₹{predicted_bill:.2f}. "
                f"{period_identifier} "
                "Visit the Prediction page to view your prediction details."
            ),
            notification_type="prediction"
        )

    # Prepare page context
    context = {
        "consumer_number": prediction_data["consumer_number"],
        "consumer_name": prediction_data["consumer_name"],
        "prediction": prediction_data["prediction"],
        "predicted_bill": prediction_data["predicted_bill"],
        "latest_consumption": prediction_data["latest_consumption"],
        "average_consumption": prediction_data["average_consumption"],
        "latest_bill_amount": prediction_data["latest_bill_amount"],
        "average_rate_per_unit": prediction_data["average_rate_per_unit"],
        "suggested_bill_goal": prediction_data["suggested_bill_goal"],
        "potential_saving": prediction_data["potential_saving"],
        "next_period_start": prediction_data["next_period_start"],
        "next_period_end": prediction_data["next_period_end"],
        "message": None,
    }

    # Render prediction page
    return render(
        request,
        "prediction.html",
        context
    )

def admin_dashboard(request):
    if "admin_username" not in request.session:
        return redirect("admin_login")

    total_users = Users.objects.count()

    return render(
        request,
        "admin_dashboard.html",
        {
            "total_users": total_users
        }
    )

def admin_weekly_upload(request):
    import csv
    import io
    from datetime import datetime, timedelta
    from decimal import Decimal, InvalidOperation

    from django.db import transaction
    from django.shortcuts import render, redirect

    # Check admin login
    if "admin_username" not in request.session:
        return redirect("admin_login")

    # Handle CSV upload
    if request.method == "POST":
        weekly_file = request.FILES.get("weekly_file")

        if not weekly_file:
            return render(
                request,
                "admin_weekly_upload.html",
                {
                    "error": "Please select a CSV file to upload."
                }
            )

        if not weekly_file.name.lower().endswith(".csv"):
            return render(
                request,
                "admin_weekly_upload.html",
                {
                    "error": "Invalid file type. Please upload a CSV file."
                }
            )

        try:
            # Read the uploaded CSV file
            file_data = weekly_file.read().decode("utf-8-sig")
            csv_data = csv.DictReader(io.StringIO(file_data))

            # Required CSV columns
            required_columns = {
                "consumer_number",
                "reading_date",
                "reading_time",
                "meter_reading",
                "slab"
            }

            headers = csv_data.fieldnames

            if not headers:
                raise ValueError(
                    "The CSV file is empty or has no header row."
                )

            # Remove spaces around column names
            headers = [
                header.strip()
                for header in headers
                if header
            ]

            if len(headers) != len(set(headers)):
                raise ValueError(
                    "The CSV contains duplicate column names."
                )

            # Check required columns
            missing_columns = required_columns - set(headers)

            if missing_columns:
                raise ValueError(
                    "Missing required columns: "
                    + ", ".join(sorted(missing_columns))
                    + "."
                )

            # Normalize column names
            csv_data.fieldnames = [
                header.strip() if header else ""
                for header in csv_data.fieldnames
            ]

            valid_readings = []

            # Validate every CSV row
            for row_number, row in enumerate(csv_data, start=2):

                if None in row:
                    raise ValueError(
                        f"Row {row_number} has more values than the header."
                    )

                if any(value is None for value in row.values()):
                    raise ValueError(
                        f"Row {row_number} has missing column values."
                    )

                consumer_number = row["consumer_number"].strip()
                date_text = row["reading_date"].strip()
                time_text = row["reading_time"].strip()
                reading_text = row["meter_reading"].strip()
                slab = row["slab"].strip()

                if not all([
                    consumer_number,
                    date_text,
                    time_text,
                    reading_text,
                    slab
                ]):
                    raise ValueError(
                        f"Row {row_number} contains an empty required value."
                    )

                # Confirm that the consumer exists
                if not Users.objects.filter(
                    consumer_number=consumer_number
                ).exists():
                    raise ValueError(
                        f"Row {row_number}: consumer number "
                        f"'{consumer_number}' does not exist."
                    )

                # Validate date, time, and meter reading
                try:
                    reading_date = datetime.strptime(
                        date_text,
                        "%Y-%m-%d"
                    ).date()

                    try:
                        reading_time = datetime.strptime(
                            time_text,
                            "%H:%M"
                        ).time()
                    except ValueError:
                        reading_time = datetime.strptime(
                            time_text,
                            "%H:%M:%S"
                        ).time()

                    meter_reading = Decimal(reading_text)

                    if (
                        not meter_reading.is_finite()
                        or meter_reading < 0
                    ):
                        raise ValueError()

                except (ValueError, InvalidOperation):
                    raise ValueError(
                        f"Row {row_number} contains an invalid date, "
                        "time, or meter reading."
                    )

                # Prepare the reading for database insertion
                valid_readings.append(
                    MeterReadings(
                        consumer_number_id=consumer_number,
                        reading_date=reading_date,
                        reading_time=reading_time,
                        meter_reading=meter_reading,
                        slab=slab
                    )
                )

            # Ensure that the CSV contains data
            if not valid_readings:
                raise ValueError(
                    "The CSV contains no data rows to upload."
                )

            # Find unique consumers in the uploaded CSV
            consumer_numbers = {
                reading.consumer_number_id
                for reading in valid_readings
            }

            # Save readings and notifications in one transaction
            with transaction.atomic():

                # Save all meter readings
                # Save all meter readings
                MeterReadings.objects.bulk_create(
                    valid_readings
                )

                # Create one normal upload notification per consumer
                for consumer_number in consumer_numbers:
                    Notification.objects.create(
                        consumer_number_id=consumer_number,
                        title="Weekly Consumption Data Updated",
                        message=(
                            "New weekly electricity readings have been "
                            "uploaded. Visit your dashboard to check your "
                            "consumption."
                        ),
                        notification_type="consumption"
                    )

                # Find the latest uploaded date for each consumer
                latest_dates = {}

                for reading in valid_readings:
                    consumer = reading.consumer_number_id

                    if (
                        consumer not in latest_dates
                        or reading.reading_date > latest_dates[consumer]
                    ):
                        latest_dates[consumer] = reading.reading_date

                # Check for unusually high daily consumption
                for consumer_number, latest_date in latest_dates.items():

                    # Get all readings up to the latest uploaded date
                    readings = MeterReadings.objects.filter(
                        consumer_number_id=consumer_number,
                        reading_date__lte=latest_date
                    ).order_by(
                        "reading_date",
                        "reading_time"
                    )

                    # Keep the final cumulative reading for each day
                    end_of_day = {}

                    for reading in readings:
                        end_of_day[reading.reading_date] = (
                            Decimal(str(reading.meter_reading))
                        )

                    previous_date = latest_date - timedelta(days=1)

                    # A daily consumption value needs the previous day's
                    # final cumulative reading
                    if (
                        latest_date not in end_of_day
                        or previous_date not in end_of_day
                    ):
                        continue

                    current_consumption = (
                        end_of_day[latest_date]
                        - end_of_day[previous_date]
                    )

                    # Collect daily consumption from the previous 7 days
                    previous_consumptions = []

                    for days_ago in range(1, 8):
                        day = latest_date - timedelta(days=days_ago)
                        day_before = day - timedelta(days=1)

                        if (
                            day in end_of_day
                            and day_before in end_of_day
                        ):
                            daily_consumption = (
                                end_of_day[day]
                                - end_of_day[day_before]
                            )

                            previous_consumptions.append(
                                daily_consumption
                            )

                    # Require at least 3 previous daily values
                    if len(previous_consumptions) < 3:
                        continue

                    average_consumption = (
                        sum(previous_consumptions)
                        / Decimal(len(previous_consumptions))
                    )

                    # Alert if consumption is more than 20% above average
                    if (
                        average_consumption > 0
                        and current_consumption
                        > average_consumption * Decimal("1.20")
                    ):
                        alert_title = "High Electricity Consumption Alert"

                        alert_message = (
                            f"Your electricity consumption on "
                            f"{latest_date} was higher than usual. "
                            f"Consumption: {current_consumption} units. "
                            "Consider reducing unnecessary electricity usage."
                        )

                        # Avoid duplicate alerts for the same date
                        already_notified = Notification.objects.filter(
                            consumer_number_id=consumer_number,
                            title=alert_title,
                            message=alert_message
                        ).exists()

                        if not already_notified:
                            Notification.objects.create(
                                consumer_number_id=consumer_number,
                                title=alert_title,
                                message=alert_message,
                                notification_type="consumption"
                            )

            # Show successful upload message
            return render(
                request,
                "admin_weekly_upload.html",
                {
                    "message": (
                        "CSV uploaded successfully! "
                        f"{len(valid_readings)} readings saved and "
                        f"{len(consumer_numbers)} consumer notifications "
                        "created."
                    )
                }
            )

        except (
            UnicodeDecodeError,
            csv.Error,
            ValueError
        ) as error:
            return render(
                request,
                "admin_weekly_upload.html",
                {
                    "error": f"Upload failed: {error}"
                }
            )

        except Exception as error:
            # The transaction rolls back if database saving fails
            print("Weekly CSV upload error:", error)

            return render(
                request,
                "admin_weekly_upload.html",
                {
                    "error": (
                        "Upload failed due to a database or server error. "
                        "Please check the server terminal and try again."
                    )
                }
            )

    # Display the upload page
    return render(request, "admin_weekly_upload.html")

def manage_users(request):

    if "admin_username" not in request.session:
        return redirect("admin_login")

    users = Users.objects.all()

    return render(
        request,
        "manage_users.html",
        {"users": users}
    )

def weekly_consumption_records(request):

    if "admin_username" not in request.session:
        return redirect("admin_login")

    search_consumer = request.GET.get(
        "consumer_number", ""
    ).strip()

    search_date = request.GET.get(
        "reading_date", ""
    ).strip()

    readings = MeterReadings.objects.all().order_by(
        "-reading_date",
        "-reading_time"
    )

    # Search by consumer number
    if search_consumer:
        readings = readings.filter(
            consumer_number__consumer_number__icontains=search_consumer
        )

    # Filter by reading date
    if search_date:
        readings = readings.filter(
            reading_date=search_date
        )

    context = {
        "readings": readings,
        "search_consumer": search_consumer,
        "search_date": search_date,
    }

    return render(
        request,
        "weekly_consumption_records.html",
        context
    )
