
from django.db import migrations, models
import django.db.models.deletion


class Migration(migrations.Migration):

    dependencies = [
        ('predictor', '0003_weeklyconsumption'),
    ]

    operations = [
        migrations.CreateModel(
            name='Notification',
            fields=[
                ('id', models.AutoField(
                    auto_created=True,
                    primary_key=True,
                    serialize=False,
                    verbose_name='ID'
                )),
                ('title', models.CharField(max_length=150)),
                ('message', models.TextField()),
                ('notification_type', models.CharField(max_length=30)),
                ('created_at', models.DateTimeField(auto_now_add=True)),
                ('is_read', models.BooleanField(default=False)),
                ('consumer_number', models.ForeignKey(
                    db_column='consumer_number',
                    on_delete=django.db.models.deletion.CASCADE,
                    to='predictor.users'
                )),
            ],
            options={
                'db_table': 'notifications',
            },
        ),
    ]
