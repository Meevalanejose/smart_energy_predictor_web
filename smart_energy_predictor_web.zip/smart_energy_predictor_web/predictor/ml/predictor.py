import os
import joblib
import pandas as pd


# =========================================================
# PREPARE DATA
# =========================================================

def prepare_data(daily_records):
    """
    Convert daily consumption records into a pandas DataFrame.
    """

    if not daily_records:
        return None

    data = []

    for record in daily_records:

        try:

            record_date = pd.to_datetime(
                record["date"]
            )

            consumption = float(
                record["consumption"]
            )

            data.append({

                "date":
                    record_date,

                "consumption":
                    consumption

            })

        except (
            ValueError,
            TypeError,
            KeyError
        ):

            continue


    if not data:
        return None


    df = pd.DataFrame(data)


    # -----------------------------------------------------
    # Sort oldest -> newest
    # -----------------------------------------------------

    df = df.sort_values(
        "date"
    ).reset_index(
        drop=True
    )


    return df


# =========================================================
# CREATE FEATURES
# =========================================================

def create_features(df):

    """
    Create the same features that were used
    while training the ML model.
    """

    df = df.copy()


    # -----------------------------------------------------
    # Previous day consumption
    # -----------------------------------------------------

    df["lag_1"] = (
        df["consumption"].shift(1)
    )


    # -----------------------------------------------------
    # Consumption from 2 days ago
    # -----------------------------------------------------

    df["lag_2"] = (
        df["consumption"].shift(2)
    )


    # -----------------------------------------------------
    # Consumption from 3 days ago
    # -----------------------------------------------------

    df["lag_3"] = (
        df["consumption"].shift(3)
    )


    # -----------------------------------------------------
    # Previous 3-day average
    # -----------------------------------------------------

    df["rolling_3"] = (

        df["consumption"]
        .rolling(
            window=3
        )
        .mean()
        .shift(1)

    )


    # -----------------------------------------------------
    # Previous 7-day average
    # -----------------------------------------------------

    df["rolling_7"] = (

        df["consumption"]
        .rolling(
            window=7
        )
        .mean()
        .shift(1)

    )


    # -----------------------------------------------------
    # Day of week
    # -----------------------------------------------------

    # Monday = 0
    # Sunday = 6

    df["day_of_week"] = (
        df["date"].dt.dayofweek
    )


    # -----------------------------------------------------
    # Weekend indicator
    # -----------------------------------------------------

    # Weekend = 1
    # Weekday = 0

    df["is_weekend"] = (

        df["day_of_week"] >= 5

    ).astype(int)


    return df


# =========================================================
# PREDICT TODAY'S CONSUMPTION
# =========================================================

def predict_today(daily_records):
    """
    Predict electricity consumption for TODAY.

    The prediction is based on historical daily
    consumption and the trained Random Forest model.
    """

    # =====================================================
    # 1. PREPARE DATA
    # =====================================================

    df = prepare_data(
        daily_records
    )


    if df is None:

        return None


    # =====================================================
    # 2. CHECK HISTORICAL DATA
    # =====================================================

    if len(df) < 7:

        return None


    # =====================================================
    # 3. LOAD TRAINED MODEL
    # =====================================================

    model_path = os.path.join(

        os.path.dirname(
            os.path.abspath(__file__)
        ),

        "energy_model.pkl"

    )


    if not os.path.exists(
        model_path
    ):

        return None


    try:

        model = joblib.load(
            model_path
        )

    except Exception:

        return None


    # =====================================================
    # 4. GET LATEST HISTORICAL VALUES
    # =====================================================

    # The database contains historical data.
    #
    # We use the latest available historical
    # consumption values as input to the model.


    lag_1 = float(

        df.iloc[-1]["consumption"]

    )


    lag_2 = float(

        df.iloc[-2]["consumption"]

    )


    lag_3 = float(

        df.iloc[-3]["consumption"]

    )


    # =====================================================
    # 5. ROLLING AVERAGES
    # =====================================================

    rolling_3 = float(

        df["consumption"]
        .tail(3)
        .mean()

    )


    rolling_7 = float(

        df["consumption"]
        .tail(7)
        .mean()

    )


    # =====================================================
    # 6. TODAY'S DATE
    # =====================================================

    today = pd.Timestamp.today().normalize()


    # =====================================================
    # 7. TODAY'S DAY OF WEEK
    # =====================================================

    day_of_week = (
        today.dayofweek
    )


    # =====================================================
    # 8. TODAY WEEKEND CHECK
    # =====================================================

    is_weekend = (

        1
        if day_of_week >= 5
        else 0

    )


    # =====================================================
    # 9. CREATE MODEL INPUT
    # =====================================================

    prediction_data = pd.DataFrame([{

        "lag_1":
            lag_1,

        "lag_2":
            lag_2,

        "lag_3":
            lag_3,

        "rolling_3":
            rolling_3,

        "rolling_7":
            rolling_7,

        "day_of_week":
            day_of_week,

        "is_weekend":
            is_weekend

    }])


    # =====================================================
    # 10. MAKE PREDICTION
    # =====================================================

    try:

        prediction = model.predict(
            prediction_data
        )[0]

    except Exception:

        return None


    # =====================================================
    # 11. PREVENT NEGATIVE VALUE
    # =====================================================

    prediction = max(

        0,

        float(
            prediction
        )

    )


    # =====================================================
    # 12. ROUND VALUE
    # =====================================================

    prediction = round(
        prediction,
        2
    )


    # =====================================================
    # 13. RETURN RESULT
    # =====================================================

    return {

        "date":
            today.date(),

        "prediction":
            prediction

    }


# =========================================================
# BACKWARD COMPATIBILITY
# =========================================================

def predict_next_day(daily_records):
    """
    Kept for compatibility with existing code.

    The project now uses predict_today() because the
    dashboard should show the prediction for the current
    date.
    """

    return predict_today(
        daily_records
    )