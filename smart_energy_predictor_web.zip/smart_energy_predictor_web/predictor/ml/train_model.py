import os
import sys
import django
import pandas as pd

from datetime import timedelta
from sklearn.ensemble import RandomForestRegressor
import joblib


# =========================================================
# DJANGO SETUP
# =========================================================

BASE_DIR = os.path.dirname(
    os.path.dirname(
        os.path.dirname(
            os.path.abspath(__file__)
        )
    )
)

sys.path.insert(0, BASE_DIR)

os.environ.setdefault(
    "DJANGO_SETTINGS_MODULE",
    "config.settings"
)

django.setup()


# =========================================================
# IMPORT MODEL
# =========================================================

from predictor.models import MeterReadings


# =========================================================
# CREATE DAILY CONSUMPTION FROM METER READINGS
# =========================================================
#
# The database contains cumulative meter readings.
#
# Example:
#
# Jan 01 -> 964 kWh
# Jan 10 -> 983 kWh
#
# Difference:
#
# 983 - 964 = 19 kWh
#
# Number of days:
#
# 9 days
#
# Estimated daily consumption:
#
# 19 / 9 = 2.11 kWh/day
#
# This estimated daily consumption is used to create
# historical daily data for ML training.
#
# =========================================================


def get_daily_records():

    readings = list(

        MeterReadings.objects.all()
        .order_by(
            "consumer_number_id",
            "reading_date",
            "reading_time",
            "id"
        )

    )

    if not readings:

        return []


    # =====================================================
    # STORE DAILY CONSUMPTION
    # =====================================================

    daily_consumption = {}


    # =====================================================
    # GROUP READINGS BY CONSUMER
    # =====================================================

    consumer_readings = {}


    for reading in readings:

        consumer_number = (
            reading.consumer_number_id
        )

        if consumer_number not in consumer_readings:

            consumer_readings[
                consumer_number
            ] = []

        consumer_readings[
            consumer_number
        ].append(reading)


    # =====================================================
    # PROCESS EACH CONSUMER
    # =====================================================

    for (
        consumer_number,
        user_readings
    ) in consumer_readings.items():

        # -------------------------------------------------
        # At least two readings are required
        # -------------------------------------------------

        if len(user_readings) < 2:

            continue


        previous_reading = None


        # =================================================
        # PROCESS READINGS
        # =================================================

        for current_reading in user_readings:


            # -------------------------------------------------
            # FIRST READING
            # -------------------------------------------------

            if previous_reading is None:

                previous_reading = (
                    current_reading
                )

                continue


            # -------------------------------------------------
            # GET METER VALUES
            # -------------------------------------------------

            try:

                previous_value = float(
                    previous_reading.meter_reading
                )

                current_value = float(
                    current_reading.meter_reading
                )

            except (
                TypeError,
                ValueError
            ):

                previous_reading = (
                    current_reading
                )

                continue


            # -------------------------------------------------
            # CALCULATE METER DIFFERENCE
            # -------------------------------------------------

            consumption = (
                current_value
                -
                previous_value
            )


            # -------------------------------------------------
            # PREVENT NEGATIVE CONSUMPTION
            # -------------------------------------------------

            if consumption < 0:

                consumption = 0.0


            # -------------------------------------------------
            # GET DATES
            # -------------------------------------------------

            previous_date = (
                previous_reading.reading_date
            )

            current_date = (
                current_reading.reading_date
            )


            # -------------------------------------------------
            # NUMBER OF DAYS BETWEEN READINGS
            # -------------------------------------------------

            days_between = (
                current_date
                -
                previous_date
            ).days


            # =================================================
            # SAME-DAY READINGS
            # =================================================

            if days_between <= 0:

                key = (
                    consumer_number,
                    current_date
                )

                if key not in daily_consumption:

                    daily_consumption[key] = 0.0

                daily_consumption[key] += (
                    consumption
                )


            # =================================================
            # DIFFERENT-DAY READINGS
            # =================================================

            else:

                # ---------------------------------------------
                # Estimate average consumption per day
                # ---------------------------------------------

                daily_average = (
                    consumption
                    /
                    days_between
                )


                # ---------------------------------------------
                # Distribute consumption across the days
                # ---------------------------------------------

                for day_number in range(
                    1,
                    days_between + 1
                ):

                    # IMPORTANT:
                    #
                    # previous_date is already a
                    # datetime.date object.
                    #
                    # Therefore we use timedelta directly.
                    #

                    daily_date = (
                        previous_date
                        +
                        timedelta(
                            days=day_number
                        )
                    )


                    key = (
                        consumer_number,
                        daily_date
                    )


                    if key not in daily_consumption:

                        daily_consumption[key] = 0.0


                    daily_consumption[key] += (
                        daily_average
                    )


            # -------------------------------------------------
            # MOVE TO NEXT READING
            # -------------------------------------------------

            previous_reading = (
                current_reading
            )


    # =========================================================
    # CONVERT DICTIONARY TO LIST
    # =========================================================

    records = []


    for (
        consumer_number,
        consumption_date
    ), consumption in sorted(
        daily_consumption.items()
    ):

        records.append({

            "consumer_number":
                consumer_number,

            "date":
                consumption_date,

            "consumption":
                round(
                    consumption,
                    2
                )

        })


    return records


# =========================================================
# CREATE FEATURES
# =========================================================


def create_features(df):

    df = df.copy()


    # -----------------------------------------------------
    # CONVERT DATE
    # -----------------------------------------------------

    df["date"] = pd.to_datetime(
        df["date"],
        errors="coerce"
    )


    # -----------------------------------------------------
    # REMOVE INVALID DATES
    # -----------------------------------------------------

    df = df.dropna(
        subset=["date"]
    ).copy()


    # =====================================================
    # LAG FEATURES
    # =====================================================

    # Previous day's consumption

    df["lag_1"] = (
        df["consumption"].shift(1)
    )


    # Consumption from 2 days ago

    df["lag_2"] = (
        df["consumption"].shift(2)
    )


    # Consumption from 3 days ago

    df["lag_3"] = (
        df["consumption"].shift(3)
    )


    # =====================================================
    # ROLLING FEATURES
    # =====================================================

    # Previous 3-day average

    df["rolling_3"] = (

        df["consumption"]
        .rolling(
            window=3
        )
        .mean()
        .shift(1)

    )


    # Previous 7-day average

    df["rolling_7"] = (

        df["consumption"]
        .rolling(
            window=7
        )
        .mean()
        .shift(1)

    )


    # =====================================================
    # DAY OF WEEK
    # =====================================================

    # Monday = 0
    # Tuesday = 1
    # ...
    # Sunday = 6

    df["day_of_week"] = (
        df["date"].dt.dayofweek
    )


    # =====================================================
    # WEEKEND
    # =====================================================

    # Weekend = 1
    # Weekday = 0

    df["is_weekend"] = (

        df["day_of_week"] >= 5

    ).astype(int)


    return df


# =========================================================
# MAIN TRAINING
# =========================================================

print()

print(
    "=============================================="
)

print(
    "SMART ENERGY PREDICTOR - ML TRAINING"
)

print(
    "=============================================="
)

print()


# =========================================================
# GET DAILY RECORDS
# =========================================================

records = get_daily_records()


if not records:

    print(
        "ERROR: No meter reading data found."
    )

    print()

    sys.exit()


# =========================================================
# CONVERT TO DATAFRAME
# =========================================================

df = pd.DataFrame(
    records
)


# =========================================================
# SORT DATA
# =========================================================

df = df.sort_values(

    [
        "consumer_number",
        "date"
    ]

).reset_index(
    drop=True
)


print(
    "Total estimated daily records:",
    len(df)
)


# =========================================================
# DISPLAY SAMPLE DATA
# =========================================================

print()

print(
    "Sample estimated daily consumption:"
)

print()

print(
    df.head(10).to_string(
        index=False
    )
)

print()


# =========================================================
# CREATE FEATURES FOR EACH CONSUMER
# =========================================================

feature_frames = []


for (
    consumer_number,
    group
) in df.groupby(
    "consumer_number"
):

    # -----------------------------------------------------
    # Sort by date
    # -----------------------------------------------------

    group = group.sort_values(
        "date"
    ).reset_index(
        drop=True
    )


    # -----------------------------------------------------
    # Create features
    # -----------------------------------------------------

    group = create_features(
        group
    )


    feature_frames.append(
        group
    )


# =========================================================
# CHECK FEATURE DATA
# =========================================================

if not feature_frames:

    print(
        "ERROR: Unable to create training data."
    )

    print()

    sys.exit()


# =========================================================
# COMBINE ALL CONSUMERS
# =========================================================

df = pd.concat(
    feature_frames,
    ignore_index=True
)


# =========================================================
# FEATURES USED BY MODEL
# =========================================================

feature_columns = [

    "lag_1",

    "lag_2",

    "lag_3",

    "rolling_3",

    "rolling_7",

    "day_of_week",

    "is_weekend"

]


# =========================================================
# REMOVE ROWS WITHOUT ENOUGH HISTORY
# =========================================================

training_df = df.dropna(

    subset=feature_columns

).copy()


print(
    "Training samples:",
    len(training_df)
)


# =========================================================
# CHECK TRAINING DATA
# =========================================================

if len(training_df) < 10:

    print()

    print(
        "ERROR: Not enough training data."
    )

    print(
        "At least 10 valid training samples "
        "are required."
    )

    print()

    sys.exit()


# =========================================================
# X AND Y
# =========================================================

X = training_df[
    feature_columns
]

y = training_df[
    "consumption"
]


# =========================================================
# RANDOM FOREST REGRESSOR
# =========================================================

model = RandomForestRegressor(

    n_estimators=100,

    random_state=42,

    max_depth=10,

    min_samples_leaf=1

)


# =========================================================
# TRAIN MODEL
# =========================================================

print()

print(
    "Training Random Forest model..."
)

print()


model.fit(
    X,
    y
)


print()

print(
    "Model training completed successfully."
)


# =========================================================
# MODEL PATH
# =========================================================

model_path = os.path.join(

    os.path.dirname(
        os.path.abspath(__file__)
    ),

    "energy_model.pkl"

)


# =========================================================
# SAVE MODEL
# =========================================================

joblib.dump(

    model,

    model_path

)


print()

print(
    "Model saved successfully."
)

print()

print(
    "Model path:"
)

print(
    model_path
)


# =========================================================
# DISPLAY MODEL FEATURES
# =========================================================

print()

print(
    "Features used by the model:"
)

print()

print(
    "1. Previous day's consumption"
)

print(
    "2. Consumption from 2 days ago"
)

print(
    "3. Consumption from 3 days ago"
)

print(
    "4. Previous 3-day average"
)

print(
    "5. Previous 7-day average"
)

print(
    "6. Day of week"
)

print(
    "7. Weekend indicator"
)


# =========================================================
# MODEL PURPOSE
# =========================================================

print()

print(
    "Model purpose:"
)

print(
    "Predict daily electricity consumption "
    "using historical consumption patterns."
)


# =========================================================
# COMPLETION
# =========================================================

print()

print(
    "=============================================="
)

print(
    "ML MODEL READY"
)

print(
    "=============================================="
)

print()