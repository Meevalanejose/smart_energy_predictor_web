from django.db import models


class Users(models.Model):
    consumer_number = models.CharField(
        primary_key=True,
        max_length=20
    )
    name = models.CharField(max_length=100)
    email = models.CharField(
        max_length=100,
        blank=True,
        null=True
    )
    phone = models.CharField(
        max_length=15,
        blank=True,
        null=True
    )
    password = models.CharField(max_length=255)

    class Meta:
        managed = False
        db_table = 'users'

    def __str__(self):
        return f"{self.consumer_number} - {self.name}"

class Admin(models.Model):
    username = models.CharField(
        max_length=50,
        unique=True
    )
    password = models.CharField(
        max_length=255
    )

    def __str__(self):
        return self.username


class WeeklyConsumption(models.Model):
    id = models.AutoField(primary_key=True)

    consumer_number = models.ForeignKey(
        Users,
        on_delete=models.CASCADE,
        db_column='consumer_number'
    )

    week_start = models.DateField()
    week_end = models.DateField()

    morning_consumption = models.DecimalField(
        max_digits=10,
        decimal_places=2
    )

    daytime_consumption = models.DecimalField(
        max_digits=10,
        decimal_places=2
    )

    evening_night_consumption = models.DecimalField(
        max_digits=10,
        decimal_places=2
    )

    total_consumption = models.DecimalField(
        max_digits=10,
        decimal_places=2
    )

    created_at = models.DateTimeField(
        auto_now_add=True
    )

    class Meta:
        db_table = 'weekly_consumption'

    def __str__(self):
        return (
            f"{self.consumer_number_id} - "
            f"{self.week_start} to {self.week_end}"
        )


class MeterReadings(models.Model):
    id = models.AutoField(primary_key=True)
    consumer_number = models.ForeignKey(
        Users,
        on_delete=models.DO_NOTHING,
        db_column='consumer_number'
    )
    reading_date = models.DateField()
    reading_time = models.TimeField()
    meter_reading = models.DecimalField(
        max_digits=10,
        decimal_places=2
    )
    slab = models.CharField(
        max_length=20,
        blank=True,
        null=True
    )

    class Meta:
        managed = False
        db_table = 'meter_readings'

    def __str__(self):
        return f"{self.consumer_number_id} - {self.reading_date}"



class ElectricityBills(models.Model):
    id = models.AutoField(primary_key=True)
    consumer_number = models.ForeignKey(
        Users,
        on_delete=models.CASCADE,
        db_column='consumer_number'
    )
    period_start = models.DateField()
    period_end = models.DateField()
    consumption_kwh = models.DecimalField(max_digits=10, decimal_places=2)
    bill_amount = models.DecimalField(max_digits=10, decimal_places=2)

    class Meta:
        db_table = 'electricity_bills'

    def __str__(self):
        return f"{self.consumer_number_id} - {self.period_start} to {self.period_end}"


    

class Notification(models.Model):
    consumer_number = models.ForeignKey(
        Users,
        on_delete=models.CASCADE,
        db_column='consumer_number'
    )

    title = models.CharField(max_length=150)
    message = models.TextField()
    notification_type = models.CharField(max_length=30)
    created_at = models.DateTimeField(auto_now_add=True)
    is_read = models.BooleanField(default=False)

    class Meta:
        db_table = 'notifications'
        ordering = ['-created_at']

    def __str__(self):
        return f"{self.consumer_number_id} - {self.title}"
